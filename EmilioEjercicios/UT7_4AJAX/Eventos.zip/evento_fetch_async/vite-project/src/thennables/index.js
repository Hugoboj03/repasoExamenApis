"use strict";
const SERVER = 'http://localhost:3000';

let eventos = [];

function getEventos() {
  fetch(`${SERVER}/eventos`)
      .then(resp => {
          // si el status no está entre 200 y 299, se produce error
          if (!resp.ok) throw new Error(`Error: ${resp.status} ${resp.statusText}`);
          return resp.json(); // convierte JSON a Objeto
      })
      .then(json => {
          console.log(json);
          eventos = json.data;
          replaceEventos();
        })
      .catch(error => {
          console.error("Fallo en la obtención de eventos:", error);
      });
}

function replaceEventos() {
  let container = document.getElementById("eventoContainer");
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }
  eventos.forEach(p => {
    appendEventos(p, container);
  });

}

function appendEventos(evento, container) {
  // Crear la tarjeta principal
  let eventoCard = document.createElement("div");
  eventoCard.className = "card mb-4";

  // Añadir la imagen a la tarjeta (si existe)
  let imgElement = document.createElement("img");
    imgElement.className = "card-img-top";
    imgElement.src = evento.imgPreview;

  eventoCard.appendChild(imgElement);

  // Crear el cuerpo de la tarjeta
  let cardCuerpo = document.createElement("div");
  cardCuerpo.className = "card-body";

  // Título del evento
  let titulo = document.createElement("h4");
  titulo.className = "card-title";
  titulo.textContent = evento.name; // Nombre del evento
  cardCuerpo.appendChild(titulo);

  // Descripción del evento
  let descripcion = document.createElement("p");
  descripcion.className = "card-text";
  descripcion.textContent = evento.description || "Sin descripción disponible.";
  cardCuerpo.appendChild(descripcion);

  eventoCard.appendChild(cardCuerpo);

  // Crear el pie de la tarjeta (fecha y precio)
  let cardFooter = document.createElement("div");
  cardFooter.className = "card-footer d-flex justify-content-between align-items-center";

  // Fecha del evento
  let fecha = document.createElement("small");
  fecha.className = "text-muted";
  fecha.textContent = `Fecha: ${evento.date || "No especificada"}`;
  cardFooter.appendChild(fecha);

  // Precio del evento
  let precio = document.createElement("span");
  precio.className = "text-success font-weight-bold";
  precio.textContent = `${evento.price ? `${evento.price} €` : "Gratis"}`;
  cardFooter.appendChild(precio);

  eventoCard.appendChild(cardFooter);

  // Añadir la tarjeta al contenedor
  container.appendChild(eventoCard);
}

getEventos();

