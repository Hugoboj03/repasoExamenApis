const SERVER = "http://localhost:8000";

// Función para obtener las rimas del servidor
async function getRimas() {
  try {
    const resp = await fetch(`${SERVER}/rimas`); // Solicitar rimas al servidor
    if (!resp.ok) throw new Error("Error al obtener las rimas.");

    const json = await resp.json();
    console.log("Respuesta del servidor:", json);

    // Verificar si los datos están en json.data o directamente en json
    const rimasDadas = json.data || json; // Usa json directamente si no hay 'data'
    console.log("Rimas obtenidas:", rimasDadas);

    if (!Array.isArray(rimasDadas)) {
      throw new Error("La respuesta del servidor no es un array válido.");
    }

    // Llamar a la función para mostrar las rimas
    displayRimas(rimasDadas);
  } catch (error) {
    console.error("Fallo al obtener las rimas:", error);
  }
}

// Función para mostrar las rimas en el contenedor
function displayRimas(rimasDadas) {
  const container = document.getElementById("rimasContainer");

  // Eliminar todos los hijos del contenedor en lugar de usar innerHTML
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }

  rimasDadas.forEach((rima) => {
    // Crear el contenedor de cada rima
    const rimaDiv = document.createElement("div");
    rimaDiv.className = "card mb-3 p-3";

    // Crear y configurar el elemento para la palabra
    const palabraElemento = document.createElement("h5");
    palabraElemento.textContent = `Palabra: ${rima.palabra}`;

    // Crear y configurar el elemento para las rimas
    const rimasElement = document.createElement("p");
    rimasElement.textContent = `Rima: ${rima.rimas.join(", ")}`;

    // Agregar elementos al contenedor de la rima
    rimaDiv.appendChild(palabraElemento);
    rimaDiv.appendChild(rimasElement);

    // Añadir al contenedor principal
    container.appendChild(rimaDiv);
  });
}

// Llamar a la función para obtener y mostrar las rimas al cargar la página
getRimas();
