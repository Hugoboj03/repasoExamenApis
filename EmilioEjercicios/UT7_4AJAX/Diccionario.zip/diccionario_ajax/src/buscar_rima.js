const SERVER = "http://localhost:8000";

document.getElementById("buscarRimaForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  // Obtención la palabra a buscar del formulario
  const palabra = document.getElementById("palabra").value.trim();
  const resultadoContenedor = document.getElementById("resultadoContenedor");

  // Limpiar resultados anteriores
  while (resultadoContenedor.firstChild) {
    resultadoContenedor.removeChild(resultadoContenedor.firstChild);
  }

  if (!palabra) {
    alert("Por favor, introduce una palabra.");
    return;
  }

  try {
    // Se solicita las rimas al servidor
    const resp = await fetch(`${SERVER}/rimas/${palabra}`);

    if (!resp.ok) {
      throw new Error("La palabra no tiene rimas asociadas o no existe en el diccionario.");
    }

    const data = await resp.json();
    const rimas = data.rimas || [];

    // Se crea el contenedor para los resultados
    const resultadoDiv = document.createElement("div");
    resultadoDiv.className = "card p-3";

    const palabraTitulo = document.createElement("h5");
    palabraTitulo.textContent = `Palabra: ${palabra}`;
    resultadoDiv.appendChild(palabraTitulo);

    //Si hay rimas se hace, sino se dice que no hay rimas asociadas.
    if (rimas.length > 0) {
      const rimasTitulo = document.createElement("h6");
      rimasTitulo.textContent = "Rimas:";
      resultadoDiv.appendChild(rimasTitulo);

      const listaRimas = document.createElement("ul");
      rimas.forEach((rima) => {
        const item = document.createElement("li");
        item.textContent = rima;
        listaRimas.appendChild(item);
      });
      resultadoDiv.appendChild(listaRimas);
    } else {
      const mensajeSinRimas = document.createElement("p");
      mensajeSinRimas.textContent = "No hay rimas asociadas para esta palabra.";
      resultadoDiv.appendChild(mensajeSinRimas);
    }

    resultadoContenedor.appendChild(resultadoDiv);
  } catch (error) {
    const mensajeError = document.createElement("p");
    mensajeError.textContent = "Hubo un error al buscar la rima.";
    mensajeError.style.color = "red";
    resultadoContenedor.appendChild(mensajeError);
  }
});
